typedef struct{
  int nbs;
  char ** mat;
  char * clr;
}t_graphe;
